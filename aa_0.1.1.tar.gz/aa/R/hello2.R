
hello_1 <- function() {
  print("Hello_1, world!")
}
